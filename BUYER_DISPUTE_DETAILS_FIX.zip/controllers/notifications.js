import ErrorHandler from "../middlewares/error.js";
import { getUserNotifications, markNotificationAsRead, markAllNotificationsAsRead, deleteNotification } from "../utils/notifications.js";
import jwt from "jsonwebtoken";

/**
 * Get all notifications for the authenticated user
 */
export const getUserNotificationsController = async (req, res, next) => {
  try {
    // Ensure we get the userId as string or ObjectId properly
    const userId = req.user._id || req.user.id;
    
    // Get role from req.user or fallback to JWT token
    let userRole = req.user.role;
    if (!userRole) {
      // Fallback: get role from JWT token
      const { token } = req.cookies;
      if (token) {
        try {
          const decoded = jwt.verify(token, process.env.JWT_SECRET);
          userRole = decoded.role;
        } catch (error) {
          // Token verification failed, continue with error
        }
      }
    }
    
    if (!userId) {
      return next(new ErrorHandler("User ID not found", 400));
    }
    
    if (!userRole) {
      return next(new ErrorHandler("User role not found", 400));
    }
    
    const { isRead, limit = 50, page = 1 } = req.query;
    
    // Convert userId to string for consistent handling
    const userIdString = userId.toString ? userId.toString() : userId;
    
    const result = await getUserNotifications(userIdString, userRole, {
      isRead: isRead !== undefined ? isRead === 'true' : undefined,
      limit: parseInt(limit),
      page: parseInt(page)
    });

    res.status(200).json({
      success: true,
      data: result
    });
  } catch (error) {
    console.error("Error in getUserNotificationsController:", error);
    next(error);
  }
};

/**
 * Mark a specific notification as read
 */
export const markNotificationAsReadController = async (req, res, next) => {
  try {
    const { notificationId } = req.params;
    const userId = req.user._id;

    const notification = await markNotificationAsRead(notificationId, userId);

    if (!notification) {
      return next(new ErrorHandler("Notification not found or access denied", 404));
    }

    res.status(200).json({
      success: true,
      message: "Notification marked as read",
      data: notification
    });
  } catch (error) {
    next(error);
  }
};

/**
 * Mark all notifications as read for the authenticated user
 */
export const markAllNotificationsAsReadController = async (req, res, next) => {
  try {
    const userId = req.user._id;
    
    // Get role from req.user or fallback to JWT token
    let userRole = req.user.role;
    if (!userRole) {
      const { token } = req.cookies;
      if (token) {
        try {
          const decoded = jwt.verify(token, process.env.JWT_SECRET);
          userRole = decoded.role;
        } catch (error) {
          // Token verification failed
        }
      }
    }
    
    if (!userRole) {
      return next(new ErrorHandler("User role not found", 400));
    }

    const result = await markAllNotificationsAsRead(userId, userRole);

    res.status(200).json({
      success: true,
      message: "All notifications marked as read",
      data: {
        modifiedCount: result.modifiedCount
      }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * Delete a specific notification
 */
export const deleteNotificationController = async (req, res, next) => {
  try {
    const { notificationId } = req.params;
    const userId = req.user._id;

    const notification = await deleteNotification(notificationId, userId);

    if (!notification) {
      return next(new ErrorHandler("Notification not found or access denied", 404));
    }

    res.status(200).json({
      success: true,
      message: "Notification deleted successfully"
    });
  } catch (error) {
    next(error);
  }
};

